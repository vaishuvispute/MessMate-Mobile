import { createInsertSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const messmateUserRole = pgEnum("messmate_user_role", [
  "customer",
  "owner",
  "kitchen_manager",
  "delivery_staff",
]);

export const mealCategory = pgEnum("messmate_meal_category", [
  "breakfast",
  "lunch",
  "snacks",
  "dinner",
]);

export const userProfilesTable = pgTable(
  "messmate_user_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    clerkUserId: varchar("clerk_user_id", { length: 255 }).notNull(),
    fullName: varchar("full_name", { length: 120 }),
    phoneNumber: varchar("phone_number", { length: 24 }),
    role: messmateUserRole("role").notNull().default("customer"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("messmate_user_profiles_clerk_user_id_idx").on(table.clerkUserId)],
);

export const mealPlansTable = pgTable("messmate_meal_plans", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description").notNull(),
  durationDays: integer("duration_days").notNull(),
  mealsPerDay: integer("meals_per_day").notNull(),
  pricePaise: integer("price_paise").notNull(),
  includedMeals: text("included_meals")
    .array()
    .notNull()
    .default(sql`ARRAY[]::text[]`),
  pauseDays: integer("pause_days").notNull().default(0),
  deliveryIncluded: boolean("delivery_included").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  isSampleData: boolean("is_sample_data").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const menuItemsTable = pgTable("messmate_menu_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  category: mealCategory("category").notNull(),
  pricePaise: integer("price_paise").notNull(),
  isVegetarian: boolean("is_vegetarian").notNull().default(true),
  allergens: text("allergens").array().notNull().default(sql`ARRAY[]::text[]`),
  imageUrl: text("image_url"),
  servedOn: date("served_on", { mode: "string" }),
  isAvailable: boolean("is_available").notNull().default(true),
  isSampleData: boolean("is_sample_data").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertUserProfileSchema = createInsertSchema(userProfilesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertMealPlanSchema = createInsertSchema(mealPlansTable).omit({
  id: true,
  createdAt: true,
});
export const insertMenuItemSchema = createInsertSchema(menuItemsTable).omit({
  id: true,
  createdAt: true,
});

export type MessmateRole = z.infer<typeof insertUserProfileSchema>["role"];
export type UserProfile = typeof userProfilesTable.$inferSelect;
export type MealPlan = typeof mealPlansTable.$inferSelect;
export type MenuItem = typeof menuItemsTable.$inferSelect;