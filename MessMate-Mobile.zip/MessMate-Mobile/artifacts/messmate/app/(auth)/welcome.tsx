import { Link, Redirect } from 'expo-router';
import { useAuth } from '@clerk/expo';
import { ImageBackground, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const thaliPhoto = require('../../assets/images/veg-thali.jpg');

export default function WelcomeScreen() {
  const colors = useColors();
  const { isLoaded, isSignedIn } = useAuth();

  if (!isLoaded) return null;
  if (isSignedIn) return <Redirect href="/" />;

  return (
    <SafeAreaView style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <View style={styles.brandRow}>
          <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
            <Text style={styles.brandInitial}>M</Text>
          </View>
          <Text style={[styles.brandName, { color: colors.foreground }]}>MessMate</Text>
        </View>

        <ImageBackground
          source={thaliPhoto}
          resizeMode="cover"
          imageStyle={styles.heroImage}
          style={styles.hero}
        >
          <View style={styles.heroShade} />
          <View style={styles.heroCopy}>
            <Text style={styles.heroEyebrow}>GOOD FOOD, MADE SIMPLE</Text>
            <Text style={styles.heroTitle}>A homely meal, right on time.</Text>
          </View>
        </ImageBackground>

        <View style={styles.bottom}>
          <Text style={[styles.heading, { color: colors.foreground }]}>
            Your everyday meal, made easy.
          </Text>
          <Text style={[styles.subheading, { color: colors.mutedForeground }]}>
            See the menu, find a plan and keep your meals in one place.
          </Text>

          <Link href="/(auth)/sign-up" asChild>
            <Pressable
              accessibilityRole="button"
              style={({ pressed }) => [
                styles.primaryButton,
                { backgroundColor: colors.primary },
                pressed && styles.pressed,
              ]}
            >
              <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>
                Create your account
              </Text>
            </Pressable>
          </Link>

          <Link href="/(auth)/sign-in" asChild>
            <Pressable
              accessibilityRole="button"
              style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]}
            >
              <Text style={[styles.secondaryText, { color: colors.foreground }]}>
                I already have an account
              </Text>
            </Pressable>
          </Link>
          <Text style={[styles.footnote, { color: colors.mutedForeground }]}>
            Secure sign-in · Your role is assigned by your mess, never self-selected
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 22, paddingTop: 16, paddingBottom: 16, gap: 18 },
  brandRow: { height: 42, flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandMark: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  brandInitial: { color: '#FFFFFF', fontSize: 18, fontFamily: 'Inter_700Bold' },
  brandName: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.2 },
  hero: { flex: 1, minHeight: 280, borderRadius: 26, overflow: 'hidden', justifyContent: 'flex-end' },
  heroImage: { borderRadius: 26 },
  heroShade: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(20, 35, 25, 0.20)' },
  heroCopy: { padding: 24, gap: 8 },
  heroEyebrow: { color: '#FBE4B8', fontSize: 10, letterSpacing: 1.7, fontFamily: 'Inter_700Bold' },
  heroTitle: { color: '#FFFFFF', fontSize: 29, lineHeight: 35, fontFamily: 'Inter_700Bold', maxWidth: 290 },
  bottom: { gap: 10, paddingTop: 2 },
  heading: { fontSize: 25, lineHeight: 31, fontFamily: 'Inter_700Bold', letterSpacing: -0.4 },
  subheading: { fontSize: 14, lineHeight: 21, fontFamily: 'Inter_400Regular', marginBottom: 4 },
  primaryButton: { height: 54, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  buttonText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  secondaryButton: { height: 48, alignItems: 'center', justifyContent: 'center' },
  secondaryText: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  footnote: { textAlign: 'center', fontSize: 11, lineHeight: 16, marginTop: 1, fontFamily: 'Inter_400Regular' },
  pressed: { opacity: 0.82 },
});