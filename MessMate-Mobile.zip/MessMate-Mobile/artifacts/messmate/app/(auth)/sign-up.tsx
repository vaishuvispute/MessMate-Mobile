import { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod/v4';
import { Link, Redirect, useRouter } from 'expo-router';
import { useAuth, useSignUp } from '@clerk/expo';
import { useUpdateCurrentProfile } from '@workspace/api-client-react';
import { AppButton, AppCard, AppShell, FormField, PageHeading } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

const signUpSchema = z.object({
  fullName: z.string().trim().min(2, 'Enter your full name.').max(120),
  phoneNumber: z
    .string()
    .trim()
    .min(7, 'Enter a valid phone number.')
    .max(24, 'Phone number is too long.')
    .regex(/^[+\d\s()-]+$/, 'Use digits and standard phone symbols only.'),
  emailAddress: z.string().trim().email('Enter a valid email address.'),
  password: z.string().min(8, 'Use at least 8 characters.'),
});

type SignUpValues = z.infer<typeof signUpSchema>;

export default function SignUpScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isLoaded, isSignedIn } = useAuth();
  const { signUp, fetchStatus } = useSignUp();
  const updateProfile = useUpdateCurrentProfile();
  const [verificationCode, setVerificationCode] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [notice, setNotice] = useState('');
  const [isWorking, setIsWorking] = useState(false);

  const { control, handleSubmit, getValues } = useForm<SignUpValues>({
    resolver: zodResolver(signUpSchema),
    defaultValues: { fullName: '', phoneNumber: '', emailAddress: '', password: '' },
  });

  if (isLoaded && isSignedIn) return <Redirect href="/" />;

  const submitDetails = handleSubmit(async (values) => {
    setNotice('');
    setIsWorking(true);
    const [firstName, ...rest] = values.fullName.trim().split(/\s+/);
    const { error } = await signUp.password({
      emailAddress: values.emailAddress.trim().toLowerCase(),
      password: values.password,
      firstName,
      lastName: rest.join(' '),
      unsafeMetadata: { phoneNumber: values.phoneNumber },
    });
    if (error) {
      setNotice(error.message);
      setIsWorking(false);
      return;
    }

    const sent = await signUp.verifications.sendEmailCode();
    if (sent.error) {
      setNotice(sent.error.message);
      setIsWorking(false);
      return;
    }
    setIsVerifying(true);
    setIsWorking(false);
  });

  const verifyEmail = async () => {
    if (verificationCode.trim().length < 4) {
      setNotice('Enter the code sent to your email.');
      return;
    }
    setIsWorking(true);
    setNotice('');
    const { error } = await signUp.verifications.verifyEmailCode({
      code: verificationCode.trim(),
    });
    if (error) {
      setNotice(error.message);
      setIsWorking(false);
      return;
    }
    if (signUp.status !== 'complete') {
      setNotice('Your email is verified, but this account needs another setup step.');
      setIsWorking(false);
      return;
    }

    try {
      await signUp.finalize();
      const values = getValues();
      await updateProfile.mutateAsync({
        data: {
          fullName: values.fullName.trim(),
          phoneNumber: values.phoneNumber.trim(),
        },
      });
      router.replace('/');
    } catch {
      Alert.alert(
        'Account created',
        'Your account is ready, but we could not save your profile details yet. You can finish them from Account.',
      );
      router.replace('/');
    } finally {
      setIsWorking(false);
    }
  };

  const busy = isWorking || fetchStatus === 'fetching';

  return (
    <AppShell>
      <View style={styles.topRow}>
        <Pressable onPress={() => router.back()} accessibilityRole="button">
          <Text style={[styles.back, { color: colors.primary }]}>‹  Back</Text>
        </Pressable>
      </View>
      <PageHeading
        eyebrow="WELCOME TO MESSMATE"
        title={isVerifying ? 'Check your inbox' : 'Create your account'}
        subtitle={
          isVerifying
            ? `We sent a verification code to ${getValues('emailAddress')}.`
            : 'Start with a secure account. Your account is created as a customer; staff roles are assigned separately.'
        }
      />

      <AppCard>
        {!isVerifying ? (
          <View style={styles.form}>
            <Controller
              control={control}
              name="fullName"
              render={({ field, fieldState }) => (
                <FormField
                  label="Full name"
                  placeholder="Your name"
                  autoComplete="name"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="phoneNumber"
              render={({ field, fieldState }) => (
                <FormField
                  label="Mobile number"
                  placeholder="+91 98765 43210"
                  keyboardType="phone-pad"
                  autoComplete="tel"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="emailAddress"
              render={({ field, fieldState }) => (
                <FormField
                  label="Email address"
                  placeholder="you@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="password"
              render={({ field, fieldState }) => (
                <FormField
                  label="Password"
                  placeholder="At least 8 characters"
                  secureTextEntry
                  autoComplete="new-password"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            <View nativeID="clerk-captcha" />
            {notice ? <Text style={[styles.notice, { color: colors.destructive }]}>{notice}</Text> : null}
            <AppButton
              label={busy ? 'Creating account…' : 'Continue'}
              disabled={busy}
              onPress={() => void submitDetails()}
            />
          </View>
        ) : (
          <View style={styles.form}>
            <FormField
              label="Verification code"
              placeholder="Enter the code"
              keyboardType="number-pad"
              autoComplete="one-time-code"
              value={verificationCode}
              onChangeText={setVerificationCode}
            />
            {notice ? <Text style={[styles.notice, { color: colors.destructive }]}>{notice}</Text> : null}
            <AppButton
              label={busy ? 'Verifying…' : 'Verify email and continue'}
              disabled={busy}
              onPress={() => void verifyEmail()}
            />
            <AppButton
              label="Send a new code"
              variant="ghost"
              disabled={busy}
              onPress={async () => {
                const { error } = await signUp.verifications.sendEmailCode();
                setNotice(error ? error.message : 'A new code has been sent.');
              }}
            />
          </View>
        )}
      </AppCard>

      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
          Already have an account?
        </Text>
        <Link href="/(auth)/sign-in" asChild>
          <Pressable accessibilityRole="link">
            <Text style={[styles.link, { color: colors.primary }]}>Sign in</Text>
          </Pressable>
        </Link>
      </View>
    </AppShell>
  );
}

const styles = StyleSheet.create({
  topRow: { minHeight: 28, justifyContent: 'center' },
  back: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  form: { gap: 16 },
  notice: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_500Medium' },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: 5, paddingVertical: 8 },
  footerText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
  link: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
});