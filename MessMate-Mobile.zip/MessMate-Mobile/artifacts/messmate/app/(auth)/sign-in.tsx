import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Link, Redirect, useRouter } from 'expo-router';
import { useAuth, useSignIn } from '@clerk/expo';
import { AppButton, AppCard, AppShell, FormField, PageHeading } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

type AuthStep = 'password' | 'mfa' | 'reset-email' | 'reset-code' | 'new-password';

export default function SignInScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isLoaded, isSignedIn } = useAuth();
  const { signIn, fetchStatus } = useSignIn();
  const [step, setStep] = useState<AuthStep>('password');
  const [emailAddress, setEmailAddress] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  if (isLoaded && isSignedIn) return <Redirect href="/" />;

  const finishSignIn = async () => {
    await signIn.finalize();
    router.replace('/');
  };

  const submitPassword = async () => {
    if (!emailAddress.trim() || !password) {
      setNotice('Enter your email address and password.');
      return;
    }
    setBusy(true);
    setNotice('');
    const { error } = await signIn.password({
      emailAddress: emailAddress.trim().toLowerCase(),
      password,
    });
    if (error) {
      setNotice(error.message);
      setBusy(false);
      return;
    }

    if (signIn.status === 'complete') {
      try {
        await finishSignIn();
      } catch {
        setNotice('We could not finish signing you in. Please try again.');
        setBusy(false);
      }
      return;
    }

    const emailFactor = signIn.supportedSecondFactors.find(
      (factor) => factor.strategy === 'email_code',
    );
    if (
      (signIn.status === 'needs_client_trust' || signIn.status === 'needs_second_factor') &&
      emailFactor
    ) {
      const sent = await signIn.mfa.sendEmailCode();
      setBusy(false);
      if (sent.error) {
        setNotice(sent.error.message);
      } else {
        setStep('mfa');
        setNotice('Enter the verification code we emailed to you.');
      }
      return;
    }

    setNotice('This account needs another verification method. Ask your mess owner to help.');
    setBusy(false);
  };

  const verifyMfa = async () => {
    setBusy(true);
    setNotice('');
    const { error } = await signIn.mfa.verifyEmailCode({ code: code.trim() });
    if (error) {
      setNotice(error.message);
      setBusy(false);
      return;
    }
    if (signIn.status === 'complete') {
      try {
        await finishSignIn();
      } catch {
        setNotice('We could not finish signing you in. Please try again.');
        setBusy(false);
      }
    } else {
      setNotice('The additional verification was not completed.');
      setBusy(false);
    }
  };

  const sendResetCode = async () => {
    if (!emailAddress.trim()) {
      setNotice('Enter the email address on your account first.');
      return;
    }
    setBusy(true);
    setNotice('');
    const created = await signIn.create({ identifier: emailAddress.trim().toLowerCase() });
    if (created.error) {
      setNotice(created.error.message);
      setBusy(false);
      return;
    }
    const sent = await signIn.resetPasswordEmailCode.sendCode();
    if (sent.error) {
      setNotice(sent.error.message);
      setBusy(false);
      return;
    }
    setStep('reset-code');
    setNotice('We sent a password reset code to your email.');
    setBusy(false);
  };

  const verifyResetCode = async () => {
    setBusy(true);
    setNotice('');
    const verified = await signIn.resetPasswordEmailCode.verifyCode({ code: code.trim() });
    if (verified.error) {
      setNotice(verified.error.message);
      setBusy(false);
      return;
    }
    setStep('new-password');
    setNotice('');
    setBusy(false);
  };

  const saveNewPassword = async () => {
    if (newPassword.length < 8) {
      setNotice('Use at least 8 characters for your new password.');
      return;
    }
    setBusy(true);
    setNotice('');
    const updated = await signIn.resetPasswordEmailCode.submitPassword({ password: newPassword });
    if (updated.error) {
      setNotice(updated.error.message);
      setBusy(false);
      return;
    }
    if (signIn.status === 'complete') {
      try {
        await finishSignIn();
      } catch {
        setNotice('Your password was updated. Sign in with your new password.');
        setStep('password');
        setBusy(false);
      }
    } else {
      setNotice('Your password was updated. Please sign in.');
      setStep('password');
      setBusy(false);
    }
  };

  const actionForStep = {
    password: submitPassword,
    mfa: verifyMfa,
    'reset-email': sendResetCode,
    'reset-code': verifyResetCode,
    'new-password': saveNewPassword,
  }[step];
  const labelForStep = {
    password: 'Sign in',
    mfa: 'Verify code',
    'reset-email': 'Send reset code',
    'reset-code': 'Verify reset code',
    'new-password': 'Update password',
  }[step];
  const titleForStep = {
    password: 'Welcome back',
    mfa: 'Confirm it’s you',
    'reset-email': 'Reset your password',
    'reset-code': 'Check your email',
    'new-password': 'Choose a new password',
  }[step];

  return (
    <AppShell>
      <View style={styles.topRow}>
        <Pressable onPress={() => (step === 'password' ? router.back() : setStep('password'))} accessibilityRole="button">
          <Text style={[styles.back, { color: colors.primary }]}>‹  {step === 'password' ? 'Back' : 'Sign in'}</Text>
        </Pressable>
      </View>
      <PageHeading
        eyebrow="MESSMATE"
        title={titleForStep}
        subtitle={
          step === 'password'
            ? 'Sign in to see your menu, meal plans and account.'
            : step === 'mfa' || step === 'reset-code'
              ? `Enter the code sent to ${emailAddress}.`
              : 'Use the email address linked to your MessMate account.'
        }
      />

      <AppCard>
        <View style={styles.form}>
          {(step === 'password' || step === 'reset-email') && (
            <FormField
              label="Email address"
              placeholder="you@example.com"
              value={emailAddress}
              onChangeText={setEmailAddress}
              autoCapitalize="none"
              keyboardType="email-address"
              autoComplete="email"
            />
          )}
          {step === 'password' && (
            <FormField
              label="Password"
              placeholder="Your password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              autoComplete="current-password"
            />
          )}
          {(step === 'mfa' || step === 'reset-code') && (
            <FormField
              label="Verification code"
              placeholder="Enter the code"
              value={code}
              onChangeText={setCode}
              keyboardType="number-pad"
              autoComplete="one-time-code"
            />
          )}
          {step === 'new-password' && (
            <FormField
              label="New password"
              placeholder="At least 8 characters"
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry
              autoComplete="new-password"
            />
          )}
          {notice ? <Text style={[styles.notice, { color: colors.destructive }]}>{notice}</Text> : null}
          <AppButton
            label={busy || fetchStatus === 'fetching' ? 'Please wait…' : labelForStep}
            onPress={() => void actionForStep()}
            disabled={busy || fetchStatus === 'fetching'}
          />
          {step === 'password' ? (
            <Pressable onPress={() => { setStep('reset-email'); setNotice(''); }} accessibilityRole="button">
              <Text style={[styles.forgot, { color: colors.primary }]}>Forgot password?</Text>
            </Pressable>
          ) : null}
          {step === 'reset-code' ? (
            <AppButton
              label="Send a new code"
              variant="ghost"
              disabled={busy}
              onPress={() => void sendResetCode()}
            />
          ) : null}
        </View>
      </AppCard>

      {step === 'password' ? (
        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>New to MessMate?</Text>
          <Link href="/(auth)/sign-up" asChild>
            <Pressable accessibilityRole="link">
              <Text style={[styles.link, { color: colors.primary }]}>Create an account</Text>
            </Pressable>
          </Link>
        </View>
      ) : null}
    </AppShell>
  );
}

const styles = StyleSheet.create({
  topRow: { minHeight: 28, justifyContent: 'center' },
  back: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  form: { gap: 16 },
  notice: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_500Medium' },
  forgot: { textAlign: 'center', fontSize: 13, fontFamily: 'Inter_600SemiBold', padding: 6 },
  footer: { flexDirection: 'row', justifyContent: 'center', gap: 5, paddingVertical: 8 },
  footerText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
  link: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
});