import { useAuth, useClerk } from '@clerk/expo';
import {
  getGetCurrentProfileQueryKey,
  useGetCurrentProfile,
} from '@workspace/api-client-react';
import { Feather } from '@expo/vector-icons';
import { Redirect, useRouter } from 'expo-router';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { AppCard, AppShell, PageHeading } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

const workspaces = {
  owner: {
    title: 'Owner workspace',
    subtitle: 'Your owner access is recognized. The management tools are being built in the next phase.',
    note: 'No menu, staff or payment changes can be made from this first release.',
  },
  kitchen_manager: {
    title: 'Kitchen workspace',
    subtitle: 'Your kitchen access is recognized. Prep lists will appear after orders are enabled.',
    note: 'Customer and payment information is not shown in this workspace.',
  },
  delivery_staff: {
    title: 'Delivery workspace',
    subtitle: 'Your delivery access is recognized. Assigned routes will appear after delivery tools are enabled.',
    note: 'Only delivery work assigned to your account will be shown here.',
  },
};

export default function StaffHomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isLoaded, isSignedIn } = useAuth();
  const { signOut } = useClerk();
  const profile = useGetCurrentProfile({
    query: {
      queryKey: getGetCurrentProfileQueryKey(),
      enabled: Boolean(isLoaded && isSignedIn),
    },
  });

  if (!isLoaded) {
    return <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View>;
  }
  if (!isSignedIn) return <Redirect href="/(auth)/welcome" />;
  if (profile.isPending) {
    return <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View>;
  }
  if (profile.isError) {
    return (
      <AppShell>
        <AppCard>
          <Text style={[styles.title, { color: colors.foreground }]}>Workspace unavailable</Text>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>
            Your staff role couldn't be checked. Try again from the account entry screen.
          </Text>
          <Pressable onPress={() => void profile.refetch()} accessibilityRole="button">
            <Text style={[styles.link, { color: colors.primary }]}>Try again</Text>
          </Pressable>
        </AppCard>
      </AppShell>
    );
  }
  if (profile.data.role === 'customer') return <Redirect href="/(tabs)" />;

  const workspace = workspaces[profile.data.role as keyof typeof workspaces];
  if (!workspace) return <Redirect href="/" />;

  return (
    <AppShell>
      <PageHeading
        eyebrow={profile.data.role.replace('_', ' ').toUpperCase()}
        title={workspace.title}
        subtitle="Your permissions come from the role assigned by your mess."
      />
      <AppCard style={styles.statusCard}>
        <View style={[styles.statusIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="lock" color={colors.primary} size={20} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>Role verified</Text>
        <Text style={[styles.body, { color: colors.mutedForeground }]}>{workspace.subtitle}</Text>
      </AppCard>
      <AppCard style={styles.infoCard}>
        <Feather name="info" color={colors.accentForeground} size={18} />
        <Text style={[styles.body, { color: colors.mutedForeground }]}>{workspace.note}</Text>
      </AppCard>
      <Pressable
        onPress={() =>
          Alert.alert('Sign out?', 'You will need to sign in again to use this workspace.', [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Sign out',
              style: 'destructive',
              onPress: async () => {
                await signOut();
                router.replace('/');
              },
            },
          ])
        }
        accessibilityRole="button"
        style={[styles.accountLink, { borderColor: colors.border }]}
      >
        <Feather name="log-out" color={colors.primary} size={17} />
        <Text style={[styles.link, { color: colors.primary }]}>Sign out of this workspace</Text>
        <Feather name="arrow-right" color={colors.primary} size={16} />
      </Pressable>
    </AppShell>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  statusCard: { alignItems: 'center', gap: 12, paddingVertical: 26 },
  statusIcon: { width: 48, height: 48, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 17, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  body: { fontSize: 13, lineHeight: 20, textAlign: 'center', fontFamily: 'Inter_400Regular' },
  infoCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  link: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  accountLink: { minHeight: 52, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
});