import { useAuth } from '@clerk/expo';
import {
  getGetCurrentProfileQueryKey,
  useGetCurrentProfile,
} from '@workspace/api-client-react';
import { Redirect } from 'expo-router';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { AppButton, ErrorState } from '@/components/messmate-ui';

export default function EntryRoute() {
  const colors = useColors();
  const { isLoaded, isSignedIn } = useAuth();
  const profile = useGetCurrentProfile({
    query: {
      queryKey: getGetCurrentProfileQueryKey(),
      enabled: Boolean(isLoaded && isSignedIn),
    },
  });

  if (!isLoaded) {
    return <Loading label="Preparing your account…" />;
  }

  if (!isSignedIn) {
    return <Redirect href="/(auth)/welcome" />;
  }

  if (profile.isPending) {
    return <Loading label="Loading your account…" />;
  }

  if (profile.isError) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <ErrorState
          title="We couldn't load your account"
          message="Check your connection and try again."
          onRetry={() => void profile.refetch()}
        />
      </SafeAreaView>
    );
  }

  return profile.data.role === 'customer' ? (
    <Redirect href="/(tabs)" />
  ) : (
    <Redirect href="/(staff)" />
  );
}

function Loading({ label }: { label: string }) {
  const colors = useColors();
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ActivityIndicator color={colors.primary} size="large" />
      <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>{label}</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 28 },
  loadingText: { marginTop: 14, textAlign: 'center', fontSize: 14, fontFamily: 'Inter_500Medium' },
});