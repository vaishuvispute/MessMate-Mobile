import { Feather } from '@expo/vector-icons';
import { useGetMealPlans, type MealPlan } from '@workspace/api-client-react';
import { useRouter } from 'expo-router';
import { StyleSheet, Text, View } from 'react-native';
import { AppButton, AppCard, AppShell, EmptyState, ErrorState, LoadingState, PageHeading, SampleBadge } from '@/components/messmate-ui';
import { formatRupees } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

export default function PlansScreen() {
  const colors = useColors();
  const router = useRouter();
  const query = useGetMealPlans();

  if (query.isPending) {
    return <AppShell><LoadingState label="Loading meal plans…" /></AppShell>;
  }
  if (query.isError) {
    return (
      <AppShell>
        <ErrorState
          title="Meal plans unavailable"
          message="We couldn't get the latest plans. Please try again."
          onRetry={() => void query.refetch()}
        />
      </AppShell>
    );
  }

  return (
    <AppShell>
      <PageHeading
        eyebrow="A ROUTINE THAT WORKS FOR YOU"
        title="Meal plans"
        subtitle="Compare what's included and choose a plan that fits your week."
      />

      {query.data.length === 0 ? (
        <EmptyState
          title="No meal plans yet"
          message="Your mess hasn't published plans yet. You can still browse the current menu."
          icon={<Feather name="calendar" color={colors.primary} size={24} />}
        />
      ) : (
        <View style={styles.list}>
          {query.data.map((plan) => <PlanCard key={plan.id} plan={plan} />)}
        </View>
      )}

      <AppCard style={styles.note}>
        <Feather name="info" color={colors.primary} size={18} />
        <Text style={[styles.noteText, { color: colors.mutedForeground }]}>
          Plan enrollment and payments are not part of this first release. No plan will be activated or charged from this screen.
        </Text>
      </AppCard>
      <AppButton
        label="Browse the menu"
        variant="secondary"
        onPress={() => router.push('/(tabs)/menu')}
      />
    </AppShell>
  );
}

function PlanCard({ plan }: { plan: MealPlan }) {
  const colors = useColors();
  return (
    <AppCard style={styles.planCard}>
      <View style={styles.planHead}>
        <View style={[styles.planIcon, { backgroundColor: colors.accent }]}>
          <Feather name="calendar" color={colors.accentForeground} size={19} />
        </View>
        <View style={styles.priceGroup}>
          <Text style={[styles.price, { color: colors.primary }]}>{formatRupees(plan.pricePaise)}</Text>
          <Text style={[styles.perDay, { color: colors.mutedForeground }]}>total plan price</Text>
        </View>
      </View>
      <Text style={[styles.planName, { color: colors.foreground }]}>{plan.name}</Text>
      <Text style={[styles.description, { color: colors.mutedForeground }]}>{plan.description}</Text>
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      <View style={styles.facts}>
        <PlanFact label="Duration" value={`${plan.durationDays} days`} />
        <PlanFact label="Daily meals" value={String(plan.mealsPerDay)} />
        <PlanFact label="Pause days" value={String(plan.pauseDays)} />
      </View>
      <View style={styles.mealsLine}>
        <Feather name="check-circle" color={colors.primary} size={15} />
        <Text style={[styles.mealsText, { color: colors.foreground }]}>
          {plan.includedMeals.length ? plan.includedMeals.join(' · ') : 'Meal details provided by your mess'}
        </Text>
      </View>
      <View style={styles.planFoot}>
        <Text style={[styles.delivery, { color: colors.mutedForeground }]}>
          {plan.deliveryIncluded ? 'Delivery included' : 'Pickup or delivery details from your mess'}
        </Text>
        {plan.isSampleData ? <SampleBadge /> : null}
      </View>
    </AppCard>
  );
}

function PlanFact({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.fact}>
      <Text style={[styles.factValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.factLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  list: { gap: 14 },
  planCard: { gap: 14 },
  planHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  planIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  priceGroup: { alignItems: 'flex-end', gap: 2 },
  price: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  perDay: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  planName: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  description: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  divider: { height: 1 },
  facts: { flexDirection: 'row', justifyContent: 'space-between' },
  fact: { gap: 4 },
  factValue: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  factLabel: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  mealsLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  mealsText: { flex: 1, fontSize: 12, lineHeight: 18, fontFamily: 'Inter_500Medium' },
  planFoot: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 10 },
  delivery: { flex: 1, fontSize: 11, fontFamily: 'Inter_400Regular' },
  note: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  noteText: { flex: 1, fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
});