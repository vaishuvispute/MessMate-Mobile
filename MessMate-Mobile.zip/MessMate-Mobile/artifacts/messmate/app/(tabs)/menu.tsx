import { useMemo, useState } from 'react';
import { Feather } from '@expo/vector-icons';
import { useGetMenuItems, type MenuItem } from '@workspace/api-client-react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { AppCard, AppShell, EmptyState, ErrorState, LoadingState, PageHeading, SampleBadge } from '@/components/messmate-ui';
import { formatRupees } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

const sampleThali = require('../../assets/images/veg-thali.jpg');
const categories: Array<'all' | MenuItem['category']> = ['all', 'breakfast', 'lunch', 'snacks', 'dinner'];

export default function MenuScreen() {
  const colors = useColors();
  const [selectedCategory, setSelectedCategory] = useState<(typeof categories)[number]>('all');
  const query = useGetMenuItems();

  const visibleItems = useMemo(
    () =>
      (query.data ?? []).filter(
        (item) => selectedCategory === 'all' || item.category === selectedCategory,
      ),
    [query.data, selectedCategory],
  );

  if (query.isPending) {
    return <AppShell><LoadingState label="Loading the menu…" /></AppShell>;
  }
  if (query.isError) {
    return (
      <AppShell>
        <ErrorState
          title="Menu unavailable"
          message="We couldn't get the latest menu. Please try again."
          onRetry={() => void query.refetch()}
        />
      </AppShell>
    );
  }

  return (
    <AppShell>
      <PageHeading
        eyebrow="FRESH FROM YOUR MESS"
        title="The menu"
        subtitle="See what's cooking and check prices before you choose."
      />

      <View style={styles.categoryList}>
        {categories.map((category) => {
          const selected = selectedCategory === category;
          return (
            <Pressable
              key={category}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => setSelectedCategory(category)}
              style={[
                styles.categoryChip,
                {
                  backgroundColor: selected ? colors.primary : colors.card,
                  borderColor: selected ? colors.primary : colors.border,
                },
              ]}
            >
              <Text style={[styles.categoryText, { color: selected ? colors.primaryForeground : colors.foreground }]}>
                {category === 'all' ? 'All meals' : category.charAt(0).toUpperCase() + category.slice(1)}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {query.data.length === 0 ? (
        <EmptyState
          title="The menu is being prepared"
          message="Your mess hasn't published menu items yet. Check back when the kitchen updates the menu."
          icon={<Feather name="coffee" color={colors.primary} size={24} />}
        />
      ) : visibleItems.length === 0 ? (
        <EmptyState
          title="No meals in this category"
          message="Try another meal category to see what's available."
          icon={<Feather name="filter" color={colors.primary} size={22} />}
        />
      ) : (
        <View style={styles.list}>
          {visibleItems.map((item) => (
            <MenuItemCard key={item.id} item={item} />
          ))}
        </View>
      )}
    </AppShell>
  );
}

function MenuItemCard({ item }: { item: MenuItem }) {
  const colors = useColors();
  const imageSource = item.imageUrl
    ? { uri: item.imageUrl }
    : item.isSampleData && (item.category === 'lunch' || item.category === 'dinner')
      ? sampleThali
      : null;
  return (
    <AppCard style={styles.itemCard}>
      {imageSource ? (
        <Image source={imageSource} accessibilityLabel={item.name} style={styles.itemImage} />
      ) : (
        <View style={[styles.imagePlaceholder, { backgroundColor: colors.secondary }]}>
          <Feather name={item.isVegetarian ? 'coffee' : 'grid'} color={colors.primary} size={24} />
        </View>
      )}
      <View style={styles.itemHeader}>
        <View style={styles.itemDetails}>
          <Text style={[styles.itemName, { color: colors.foreground }]}>{item.name}</Text>
          <Text style={[styles.itemDescription, { color: colors.mutedForeground }]}>{item.description}</Text>
        </View>
        <Text style={[styles.itemPrice, { color: colors.primary }]}>{formatRupees(item.pricePaise)}</Text>
      </View>
      <View style={styles.itemFooter}>
        <View style={styles.tags}>
          <View style={[styles.tag, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.tagText, { color: colors.secondaryForeground }]}>
              {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
            </Text>
          </View>
          {item.isVegetarian ? (
            <View style={[styles.tag, { backgroundColor: '#E8F3E9' }]}>
              <Text style={[styles.tagText, { color: '#246B49' }]}>Vegetarian</Text>
            </View>
          ) : null}
        </View>
        {item.isSampleData ? <SampleBadge /> : null}
      </View>
      {item.allergens.length ? (
        <Text style={[styles.allergens, { color: colors.mutedForeground }]}>
          Contains: {item.allergens.join(', ')}
        </Text>
      ) : null}
    </AppCard>
  );
}

const styles = StyleSheet.create({
  categoryList: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  categoryChip: { borderWidth: 1, borderRadius: 100, paddingHorizontal: 14, paddingVertical: 9 },
  categoryText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  list: { gap: 14 },
  itemCard: { padding: 12, gap: 13 },
  itemImage: { width: '100%', height: 168, borderRadius: 15 },
  imagePlaceholder: { width: '100%', height: 110, alignItems: 'center', justifyContent: 'center', borderRadius: 15 },
  itemHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  itemDetails: { flex: 1, gap: 5 },
  itemName: { fontSize: 17, lineHeight: 22, fontFamily: 'Inter_700Bold' },
  itemDescription: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_400Regular' },
  itemPrice: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  itemFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  tag: { borderRadius: 100, paddingHorizontal: 9, paddingVertical: 5 },
  tagText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  allergens: { fontSize: 11, fontFamily: 'Inter_400Regular' },
});