import { useUser } from '@clerk/expo';
import { useGetCurrentProfile, useGetMealPlans, useGetMenuItems } from '@workspace/api-client-react';
import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ImageBackground, Pressable, StyleSheet, Text, View } from 'react-native';
import { AppButton, AppCard, AppShell, ErrorState, formatRupees, LoadingState, PageHeading, SampleBadge, SectionHeading } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

const thaliPhoto = require('../../assets/images/veg-thali.jpg');

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useUser();
  const profile = useGetCurrentProfile();
  const menu = useGetMenuItems();
  const plans = useGetMealPlans();

  if (profile.isPending || menu.isPending || plans.isPending) {
    return (
      <AppShell>
        <LoadingState label="Loading your MessMate…" />
      </AppShell>
    );
  }

  if (profile.isError || menu.isError || plans.isError) {
    return (
      <AppShell>
        <ErrorState
          title="We couldn't load your home"
          message="Check your connection and try again."
          onRetry={() => void Promise.all([profile.refetch(), menu.refetch(), plans.refetch()])}
        />
      </AppShell>
    );
  }

  const menuItems = menu.data;
  const firstPlan = plans.data[0];
  const firstName = profile.data.fullName?.trim().split(/\s+/)[0] || user?.firstName || 'there';
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <AppShell>
      <PageHeading
        eyebrow="YOUR MEALS, SORTED"
        title={`${greeting}, ${firstName}`}
        subtitle="Fresh meals and a simpler daily routine."
      />

      <ImageBackground source={thaliPhoto} imageStyle={styles.heroImage} style={styles.hero}>
        <View style={styles.heroShade} />
        <View style={styles.heroTop}>
          <Text style={styles.heroEyebrow}>MADE FOR YOUR EVERYDAY</Text>
          <Feather name="sun" size={20} color="#FBE3B7" />
        </View>
        <View style={styles.heroBottom}>
          <Text style={styles.heroTitle}>A good meal makes the day.</Text>
          <Text style={styles.heroText}>See what's cooking and plan ahead.</Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/(tabs)/menu')}
            style={({ pressed }) => [styles.heroButton, pressed && { opacity: 0.84 }]}
          >
            <Text style={[styles.heroButtonText, { color: colors.foreground }]}>See today's menu</Text>
            <Feather name="arrow-up-right" color={colors.foreground} size={16} />
          </Pressable>
        </View>
      </ImageBackground>

      <View style={styles.section}>
        <SectionHeading
          title="Today's menu"
          action="View all"
          onAction={() => router.push('/(tabs)/menu')}
        />
        {menuItems.length ? (
          menuItems.slice(0, 2).map((item) => (
            <AppCard key={item.id} style={styles.menuPreview}>
              <View style={styles.menuPreviewTop}>
                <View style={styles.menuTitleGroup}>
                  <Text style={[styles.itemName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.itemCategory, { color: colors.mutedForeground }]}>
                    {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                    {item.isVegetarian ? '  ·  Vegetarian' : ''}
                  </Text>
                </View>
                <Text style={[styles.price, { color: colors.primary }]}>{formatRupees(item.pricePaise)}</Text>
              </View>
              {item.isSampleData ? <SampleBadge /> : null}
            </AppCard>
          ))
        ) : (
          <AppCard style={styles.emptyCard}>
            <Feather name="coffee" color={colors.primary} size={20} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Menu is being prepared</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Your mess hasn't published any meals yet. Check back soon.
            </Text>
          </AppCard>
        )}
      </View>

      <View style={styles.section}>
        <SectionHeading title="Find your meal plan" action="Explore" onAction={() => router.push('/(tabs)/plans')} />
        {firstPlan ? (
          <AppCard style={styles.planCard}>
            <View style={styles.planTop}>
              <View style={[styles.planIcon, { backgroundColor: colors.accent }]}>
                <Feather name="calendar" color={colors.accentForeground} size={18} />
              </View>
              <Text style={[styles.planPrice, { color: colors.primary }]}>{formatRupees(firstPlan.pricePaise)}</Text>
            </View>
            <Text style={[styles.planName, { color: colors.foreground }]}>{firstPlan.name}</Text>
            <Text style={[styles.itemCategory, { color: colors.mutedForeground }]}>
              {firstPlan.durationDays} days · {firstPlan.mealsPerDay} meal{firstPlan.mealsPerDay === 1 ? '' : 's'} per day
            </Text>
            {firstPlan.isSampleData ? <SampleBadge /> : null}
          </AppCard>
        ) : (
          <AppCard style={styles.emptyCard}>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No plans published yet</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Meal plans will appear here once your mess adds them.
            </Text>
          </AppCard>
        )}
      </View>

      <AppCard style={styles.noteCard}>
        <Feather name="shield" size={17} color={colors.primary} />
        <Text style={[styles.noteText, { color: colors.mutedForeground }]}>
          Your account is protected. MessMate assigns customer and staff access separately.
        </Text>
      </AppCard>
    </AppShell>
  );
}

const styles = StyleSheet.create({
  hero: { minHeight: 264, borderRadius: 24, overflow: 'hidden', padding: 20, justifyContent: 'space-between' },
  heroImage: { borderRadius: 24 },
  heroShade: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(18, 37, 26, 0.34)' },
  heroTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroEyebrow: { color: '#FBE3B7', letterSpacing: 1.4, fontSize: 10, fontFamily: 'Inter_700Bold' },
  heroBottom: { gap: 8, alignItems: 'flex-start' },
  heroTitle: { color: '#FFFFFF', fontSize: 25, lineHeight: 30, fontFamily: 'Inter_700Bold', maxWidth: 260 },
  heroText: { color: '#F7F7F1', fontSize: 13, fontFamily: 'Inter_400Regular' },
  heroButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 13,
    paddingVertical: 10,
    marginTop: 4,
  },
  heroButtonText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  section: { gap: 12 },
  menuPreview: { padding: 15, gap: 12 },
  menuPreviewTop: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, alignItems: 'center' },
  menuTitleGroup: { flex: 1, gap: 4 },
  itemName: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  itemCategory: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  price: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  emptyCard: { alignItems: 'center', paddingVertical: 24, gap: 9 },
  emptyTitle: { fontSize: 15, fontFamily: 'Inter_600SemiBold', textAlign: 'center' },
  emptyText: { fontSize: 13, lineHeight: 19, textAlign: 'center', fontFamily: 'Inter_400Regular' },
  planCard: { gap: 9 },
  planTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  planIcon: { width: 38, height: 38, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  planPrice: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  planName: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  noteCard: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 15 },
  noteText: { flex: 1, fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
});