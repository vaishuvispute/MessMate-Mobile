import { useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod/v4';
import { Feather } from '@expo/vector-icons';
import { useClerk, useUser } from '@clerk/expo';
import { useGetCurrentProfile, useUpdateCurrentProfile } from '@workspace/api-client-react';
import { useRouter } from 'expo-router';
import { AppButton, AppCard, AppShell, ErrorState, FormField, LoadingState, PageHeading } from '@/components/messmate-ui';
import { useColors } from '@/hooks/useColors';

const profileSchema = z.object({
  fullName: z.string().trim().min(2, 'Enter your full name.').max(120),
  phoneNumber: z
    .string()
    .trim()
    .min(7, 'Enter a valid phone number.')
    .max(24, 'Phone number is too long.')
    .regex(/^[+\d\s()-]+$/, 'Use digits and standard phone symbols only.'),
});
type ProfileValues = z.infer<typeof profileSchema>;

const roleNames: Record<string, string> = {
  customer: 'Customer',
  owner: 'Mess owner',
  kitchen_manager: 'Kitchen team',
  delivery_staff: 'Delivery team',
};

export default function ProfileScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useUser();
  const { signOut } = useClerk();
  const profile = useGetCurrentProfile();
  const updateProfile = useUpdateCurrentProfile();
  const [editing, setEditing] = useState(false);
  const [notice, setNotice] = useState('');

  const { control, handleSubmit, reset } = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: { fullName: '', phoneNumber: '' },
  });

  useEffect(() => {
    const unsafePhone = user?.unsafeMetadata?.phoneNumber;
    reset({
      fullName: profile.data?.fullName ?? user?.fullName ?? '',
      phoneNumber:
        profile.data?.phoneNumber ??
        (typeof unsafePhone === 'string' ? unsafePhone : ''),
    });
  }, [profile.data?.fullName, profile.data?.phoneNumber, reset, user]);

  const saveProfile = handleSubmit(async (values) => {
    setNotice('');
    try {
      await updateProfile.mutateAsync({
        data: {
          fullName: values.fullName.trim(),
          phoneNumber: values.phoneNumber.trim(),
        },
      });
      await profile.refetch();
      setEditing(false);
    } catch {
      setNotice('Your details could not be saved. Check your connection and retry.');
    }
  });

  const confirmSignOut = () => {
    Alert.alert('Sign out?', 'You will need to sign in again to view your account.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign out',
        style: 'destructive',
        onPress: async () => {
          await signOut();
          router.replace('/');
        },
      },
    ]);
  };

  if (profile.isPending) {
    return <AppShell><LoadingState label="Loading your account…" /></AppShell>;
  }
  if (profile.isError) {
    return (
      <AppShell>
        <ErrorState
          title="Account details unavailable"
          message="We couldn't load your profile. Please try again."
          onRetry={() => void profile.refetch()}
        />
      </AppShell>
    );
  }

  const fullName = profile.data.fullName || user?.fullName || 'Your name';
  const email = user?.primaryEmailAddress?.emailAddress ?? 'No email address';
  const role = roleNames[profile.data.role] ?? 'Account';
  const phone = profile.data.phoneNumber || (typeof user?.unsafeMetadata?.phoneNumber === 'string' ? user.unsafeMetadata.phoneNumber : '');

  return (
    <AppShell>
      <PageHeading
        eyebrow="YOUR MESSMATE ACCOUNT"
        title="Account"
        subtitle="Manage your personal details and secure access."
      />

      <AppCard style={styles.identityCard}>
        <View style={[styles.avatar, { backgroundColor: colors.secondary }]}>
          <Text style={[styles.avatarText, { color: colors.primary }]}>
            {(fullName.trim()[0] || 'M').toUpperCase()}
          </Text>
        </View>
        <View style={styles.identity}>
          <Text style={[styles.name, { color: colors.foreground }]}>{fullName}</Text>
          <Text style={[styles.email, { color: colors.mutedForeground }]}>{email}</Text>
        </View>
        <View style={[styles.roleBadge, { backgroundColor: colors.accent }]}>
          <Text style={[styles.roleText, { color: colors.accentForeground }]}>{role}</Text>
        </View>
      </AppCard>

      <AppCard style={styles.detailsCard}>
        <View style={styles.cardHeader}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>Personal details</Text>
          {!editing ? (
            <Pressable onPress={() => setEditing(true)} accessibilityRole="button">
              <Text style={[styles.edit, { color: colors.primary }]}>Edit</Text>
            </Pressable>
          ) : null}
        </View>

        {editing ? (
          <View style={styles.form}>
            <Controller
              control={control}
              name="fullName"
              render={({ field, fieldState }) => (
                <FormField
                  label="Full name"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            <Controller
              control={control}
              name="phoneNumber"
              render={({ field, fieldState }) => (
                <FormField
                  label="Mobile number"
                  keyboardType="phone-pad"
                  value={field.value}
                  onChangeText={field.onChange}
                  onBlur={field.onBlur}
                  error={fieldState.error?.message}
                />
              )}
            />
            {notice ? <Text style={[styles.notice, { color: colors.destructive }]}>{notice}</Text> : null}
            <AppButton
              label={updateProfile.isPending ? 'Saving…' : 'Save details'}
              disabled={updateProfile.isPending}
              onPress={() => void saveProfile()}
            />
            <AppButton label="Cancel" variant="ghost" onPress={() => { setEditing(false); setNotice(''); }} />
          </View>
        ) : (
          <View style={styles.detailList}>
            <DetailRow label="Full name" value={fullName} />
            <DetailRow label="Mobile number" value={phone || 'Add a mobile number'} />
            <DetailRow label="Email address" value={email} />
          </View>
        )}
      </AppCard>

      <AppCard style={styles.securityCard}>
        <View style={[styles.securityIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="shield" color={colors.primary} size={18} />
        </View>
        <View style={styles.securityCopy}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>Secure account</Text>
          <Text style={[styles.email, { color: colors.mutedForeground }]}>
            Your sign-in is protected. Account roles are controlled by the mess, not by this app.
          </Text>
        </View>
      </AppCard>

      <AppButton label="Sign out" variant="secondary" onPress={confirmSignOut} />
      <Text style={[styles.version, { color: colors.mutedForeground }]}>MessMate · Phase 1</Text>
    </AppShell>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.detailRow}>
      <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  identityCard: { flexDirection: 'row', alignItems: 'center', gap: 13, flexWrap: 'wrap' },
  avatar: { width: 52, height: 52, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 22, fontFamily: 'Inter_700Bold' },
  identity: { flex: 1, gap: 4, minWidth: 140 },
  name: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  email: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  roleBadge: { borderRadius: 100, paddingHorizontal: 10, paddingVertical: 6 },
  roleText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  detailsCard: { gap: 17 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardTitle: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  edit: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  detailList: { gap: 16 },
  detailRow: { gap: 4 },
  detailLabel: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  detailValue: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  form: { gap: 15 },
  notice: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_500Medium' },
  securityCard: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  securityIcon: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  securityCopy: { flex: 1, gap: 5 },
  version: { textAlign: 'center', fontSize: 11, fontFamily: 'Inter_400Regular' },
});