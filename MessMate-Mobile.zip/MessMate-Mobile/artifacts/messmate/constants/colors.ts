/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#1C2C22',
    tint: '#246B49',

    // Core surfaces
    background: '#F7F8F3',
    foreground: '#1C2C22',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#1C2C22',

    // Primary action color (buttons, links, active states)
    primary: '#246B49',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E9EFE9',
    secondaryForeground: '#304238',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EEF0E9',
    mutedForeground: '#718076',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#FFF0DA',
    accentForeground: '#9A5A16',

    // Destructive actions (delete, error states)
    destructive: '#C83F3F',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#E2E8DF',
    input: '#D8E1D8',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
