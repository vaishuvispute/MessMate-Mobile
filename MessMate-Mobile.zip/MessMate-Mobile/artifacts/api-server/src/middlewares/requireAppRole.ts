import { getAuth } from "@clerk/express";
import { db, userProfilesTable, type MessmateRole } from "@workspace/db";
import { eq } from "drizzle-orm";
import type { RequestHandler } from "express";

export function requireAppRole(...allowedRoles: MessmateRole[]): RequestHandler {
  return async (req, res, next) => {
    const userId = getAuth(req).userId;
    if (!userId) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }

    const [profile] = await db
      .select({ role: userProfilesTable.role })
      .from(userProfilesTable)
      .where(eq(userProfilesTable.clerkUserId, userId))
      .limit(1);

    if (!profile || !allowedRoles.includes(profile.role)) {
      res.status(403).json({ error: "You do not have permission for this action" });
      return;
    }

    next();
  };
}