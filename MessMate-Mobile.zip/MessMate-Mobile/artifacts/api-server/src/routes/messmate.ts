import { getAuth } from "@clerk/express";
import {
  db,
  mealPlansTable,
  menuItemsTable,
  userProfilesTable,
} from "@workspace/db";
import { UpdateCurrentProfileBody } from "@workspace/api-zod";
import { asc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";

const router: IRouter = Router();

function getSignedInUserId(req: Parameters<typeof getAuth>[0]): string | null {
  return getAuth(req).userId ?? null;
}

router.get("/v1/profile/me", async (req, res) => {
  const clerkUserId = getSignedInUserId(req);
  if (!clerkUserId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  await db
    .insert(userProfilesTable)
    .values({ clerkUserId })
    .onConflictDoNothing({ target: userProfilesTable.clerkUserId });

  const [profile] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.clerkUserId, clerkUserId))
    .limit(1);

  if (!profile) {
    res.status(500).json({ error: "Could not load your profile" });
    return;
  }

  res.json(profile);
});

router.patch("/v1/profile/me", async (req, res) => {
  const clerkUserId = getSignedInUserId(req);
  if (!clerkUserId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const parsed = UpdateCurrentProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please check your profile details" });
    return;
  }

  const [profile] = await db
    .insert(userProfilesTable)
    .values({
      clerkUserId,
      fullName: parsed.data.fullName,
      phoneNumber: parsed.data.phoneNumber ?? null,
    })
    .onConflictDoUpdate({
      target: userProfilesTable.clerkUserId,
      set: {
        fullName: parsed.data.fullName,
        phoneNumber: parsed.data.phoneNumber ?? null,
        updatedAt: new Date(),
      },
    })
    .returning();

  if (!profile) {
    res.status(500).json({ error: "Could not save your profile" });
    return;
  }

  res.json(profile);
});

router.get("/v1/menu", async (req, res) => {
  if (!getSignedInUserId(req)) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const items = await db
    .select()
    .from(menuItemsTable)
    .where(eq(menuItemsTable.isAvailable, true))
    .orderBy(asc(menuItemsTable.category), asc(menuItemsTable.name));
  res.json(items);
});

router.get("/v1/meal-plans", async (req, res) => {
  if (!getSignedInUserId(req)) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const plans = await db
    .select()
    .from(mealPlansTable)
    .where(eq(mealPlansTable.isActive, true))
    .orderBy(asc(mealPlansTable.pricePaise));
  res.json(plans);
});

export default router;