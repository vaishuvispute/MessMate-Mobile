import { Router, type IRouter } from "express";
import healthRouter from "./health";
import messmateRouter from "./messmate";

const router: IRouter = Router();

router.use(healthRouter);
router.use(messmateRouter);

export default router;
