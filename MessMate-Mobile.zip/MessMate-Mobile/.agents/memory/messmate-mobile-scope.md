---
name: MessMate mobile scope
description: The user's standing constraint for how MessMate must be built.
---

MessMate must be a real native mobile app built with React Native, Expo, and TypeScript—not a website or WebView.

**Why:** the user emphasized this while correcting the implementation direction.

**How to apply:** keep features in the MessMate mobile artifact and use native React Native screens and APIs. Do not substitute a web artifact or embedded website unless the user later asks for one.